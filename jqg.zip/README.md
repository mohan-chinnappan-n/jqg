# Gantt chart LWC 

- [Component](force-app/main/default/lwc/jqg.js)
- [Apex class](force-app/main/default/classes/Tasks.cls)
- [Staticresources](force-app/main/default/staticresources)
